package com.swe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * purpose : The main controller class , starting the Spring boot application, 
 * our application is about educational web_site with different courses that 
 * contains different games that can be added only by a teacher , and played 
 * by both teacher and student .
 * @author  : Doaa Ghaleb , Roqaia Ahmed , Hagar Mohamed , Ezzat Hany , Amr Almaz.
 * @version : 4.6.3 .
 */

@SpringBootApplication
public class MainController {
	
	 /**
     * Main method, used to run the application.
     */
	
	public static void main(String[] args) {
		SpringApplication.run(MainController.class, args);
			
			
		}

}
